import Card from '../UI/Card';

const BarChart = props => {
  return (
    <Card>
      <h2>Awareness</h2>
    </Card>
  )
};

export default BarChart;