import Card from '../UI/Card';

const ScatterplotD3Controlled = props => {
  return (
    <Card>
      <h2>Retention vs Usage</h2>
    </Card>
  )
};

export default ScatterplotD3Controlled;