const Label = props => {
  return (
    <text></text>
  );
};

export default Label;