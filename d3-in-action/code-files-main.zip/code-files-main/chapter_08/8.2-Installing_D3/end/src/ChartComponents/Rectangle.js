const Rectangle = props => {
  return (
    <rect />
  )
};

export default Rectangle;