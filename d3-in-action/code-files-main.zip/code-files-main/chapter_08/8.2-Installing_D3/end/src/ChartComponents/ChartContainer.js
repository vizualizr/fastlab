const ChartContainer = props => {
  return (
    <svg></svg>
  );
};

export default ChartContainer;