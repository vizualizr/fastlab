const Circle = props => {
  return (
    <circle />
  )
};

export default Circle;