const Curve = props => {
  return <path />
};

export default Curve;