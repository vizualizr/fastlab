const Badge = props => {
  return (
    <g></g>
  );
};

export default Badge;