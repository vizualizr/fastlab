// Colors
const slateGray = "#305252";
const gray = "#606464";
const white = "#faffff";
const womenColor = "#826C7F";
const menColor = "#FA7E61";