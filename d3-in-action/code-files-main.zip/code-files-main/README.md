# book-exercises
This repository contains the starting code files and solutions of the book D3.js in Action, 3rd edition](https://www.manning.com/books/d3js-in-action-third-edition).
