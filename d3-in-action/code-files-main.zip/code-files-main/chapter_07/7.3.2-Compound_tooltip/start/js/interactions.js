const createTooltip = (data) => {

  const tooltipWidth = 100;
  const tooltipHeight = 190;
  const textColor = "#494e4f";
  const textLineHeight = 22;

  // Create the tooltip here

};

const handleMouseEvents = (data) => {

  // Handle the mouse events here

};