/*************************************/
/*  Create and populate the filters  */
/*************************************/
const populateFilters = (data) => {

  // Create the filters here

};


/****************************/
/*   Update the histogram   */
/****************************/
const updateHistogram = (selectedFilter, data) => {
  
  // Update the histogram here

};