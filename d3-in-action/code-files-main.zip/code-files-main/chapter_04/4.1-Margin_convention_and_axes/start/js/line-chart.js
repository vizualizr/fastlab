// Load the data here

// Create the line chart here
const drawLineChart = (data) => {

};