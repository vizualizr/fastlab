const addLegend = () => {
  // Create the legend here

  
};