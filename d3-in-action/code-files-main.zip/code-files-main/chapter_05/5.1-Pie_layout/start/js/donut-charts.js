const drawDonutCharts = (data) => {
  // Generate the donut charts here

  
};